import React from "react";
import "./App.css";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import TopMenu from "./Components/TopMenu";
import LandingPage from "./Components/LandingPage";
import ContactUs from "./Components/ContactUs";
import Products from "./Components/Products/Products";

function App() {
  return (
    <Router>
      <div className="App">
        <TopMenu />
        <Routes>
          <Route exact path="/Products">
            <Products />
          </Route>
          <Route exact path="/ContactUs">
            <ContactUs />
          </Route>
          <Route exact path="/Components/LandingPage">
            <LandingPage />
          </Route>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
