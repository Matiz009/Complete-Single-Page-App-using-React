import React from "react";
const TopMenu = () => {
  return (
    <div>
      <ul>
        <li>
          <a href="/">Home</a>
        </li>
        <li>
          <a href="/Products">Products</a>
        </li>
        <li>
          <a href="/ContactUs">Contact Us</a>
        </li>
      </ul>
    </div>
  );
};

export default TopMenu;
